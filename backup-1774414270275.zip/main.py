#!/usr/bin/env python3
import os
import json
import time
import asyncio
from typing import Optional, Dict, List

import aiohttp
import discord
from discord import app_commands
from discord.ui import View, Button, Select, SelectOption, Modal, TextInput
from dotenv import load_dotenv

load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
API_BASE = os.getenv("API_BASE", "https://salas-bot.freefireapi.online")
KEY_FILE = os.getenv("KEY_FILE", "keys.json")
SETTINGS_FILE = os.getenv("SETTINGS_FILE", "settings.json")
# Comma-separated guild ids for instant command registration (ex: "12345,67890")
GUILD_IDS_ENV = os.getenv("GUILD_IDS", "").strip()

# Parse guild ids into list of ints (if provided)
def _parse_guild_ids(raw: str) -> List[int]:
    if not raw:
        return []
    out = []
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out.append(int(part))
        except ValueError:
            # ignore invalid entries
            pass
    return out

GUILD_IDS = _parse_guild_ids(GUILD_IDS_ENV)

if not DISCORD_TOKEN:
    raise SystemExit("ERRO: defina DISCORD_TOKEN no .env")

intents = discord.Intents.default()
bot = discord.Client(intents=intents)
tree = app_commands.CommandTree(bot)

# In-memory rate-limit map: key -> last_create_timestamp
last_create_by_key: Dict[str, float] = {}

# --- Simple JSON storage helpers (local files) ---
def load_json(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_json(path: str, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_user_key(user_id: int) -> Optional[str]:
    keys = load_json(KEY_FILE)
    return keys.get(str(user_id))

def set_user_key(user_id: int, key: str) -> None:
    keys = load_json(KEY_FILE)
    keys[str(user_id)] = key
    save_json(KEY_FILE, keys)

def get_user_settings(user_id: int) -> dict:
    settings = load_json(SETTINGS_FILE)
    return settings.get(str(user_id), {})

def set_user_setting(user_id: int, k: str, v) -> None:
    settings = load_json(SETTINGS_FILE)
    user = settings.setdefault(str(user_id), {})
    user[k] = v
    save_json(SETTINGS_FILE, settings)

# --- Modals reused from config (Key, Senha, Timer) ---
class KeyModal(Modal, title="Resgatar / Registrar Key"):
    key = TextInput(label="Sua oauth_key (SALABOT-...)", placeholder="SALABOT-ABCD1234...", max_length=128)
    def __init__(self, user_id: int):
        super().__init__()
        self.user_id = user_id
    async def on_submit(self, interaction: discord.Interaction):
        set_user_key(self.user_id, self.key.value.strip())
        await interaction.response.send_message("✅ Key salva com sucesso (ephemeral).", ephemeral=True)

class SenhaModal(Modal, title="Definir Senha Fixa"):
    senha = TextInput(label="Senha numérica (apenas dígitos)", placeholder="Ex: 1234", max_length=8)
    def __init__(self, user_id: int):
        super().__init__()
        self.user_id = user_id
    async def on_submit(self, interaction: discord.Interaction):
        raw = self.senha.value.strip()
        if not raw.isdigit():
            await interaction.response.send_message("❌ Senha inválida: apenas dígitos.", ephemeral=True)
            return
        set_user_setting(self.user_id, "senha_fixa", raw)
        await interaction.response.send_message("✅ Senha fixa salva (ephemeral).", ephemeral=True)

class TimerModal(Modal, title="Configurar Timer (auto_start)"):
    minutes = TextInput(label="Auto start (minutos, 1-8)", placeholder="Ex: 5", max_length=2)
    def __init__(self, user_id: int):
        super().__init__()
        self.user_id = user_id
    async def on_submit(self, interaction: discord.Interaction):
        raw = self.minutes.value.strip()
        if not raw.isdigit():
            await interaction.response.send_message("❌ Valor inválido.", ephemeral=True)
            return
        val = int(raw)
        if not (1 <= val <= 8):
            await interaction.response.send_message("❌ Valor inválido: 1-8 minutos.", ephemeral=True)
            return
        set_user_setting(self.user_id, "auto_start", val)
        await interaction.response.send_message(f"✅ Auto start salvo: {val} minuto(s).", ephemeral=True)

# --- Helper: API create room ---
async def create_room_with_key(key: str, payload: dict) -> dict:
    # Respect local rate limit per key (1.2s)
    now = time.time()
    last = last_create_by_key.get(key, 0)
    elapsed = now - last
    if elapsed < 1.2:
        await asyncio.sleep(1.2 - elapsed)
    headers = {"Authorization": key, "Content-Type": "application/json"}
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{API_BASE}/api/v1/create:room", json=payload, headers=headers, timeout=15) as r:
            last_create_by_key[key] = time.time()
            try:
                return await r.json()
            except Exception:
                return {"status": "ERRO", "msg": f"Resposta inesperada ({r.status})"}

# (O restante do código de comandos, views, select e tasks segue igual ao protótipo anterior)
# Para manter a resposta curta, não repito tudo aqui — preserve sua implementação atual
# abaixo adicionei a lógica de sincronização automática dos comandos no on_ready.

@bot.event
async def on_ready():
    # Sincroniza comandos automaticamente:
    try:
        if GUILD_IDS:
            # Sync por guild (aparecem imediatamente nesses servidores)
            for gid in GUILD_IDS:
                try:
                    guild_obj = discord.Object(id=gid)
                    await tree.sync(guild=guild_obj)
                    print(f"[commands] Sincronizados comandos no guild {gid}")
                except Exception as e:
                    print(f"[commands] Erro ao sincronizar guild {gid}: {e}")
        else:
            # Sync global (pode demorar até ~1h para propagar)
            await tree.sync()
            print("[commands] Comandos sincronizados globalmente (pode levar até 1 hora para aparecer).")
    except Exception as e:
        print(f"[commands] Falha ao sincronizar comandos: {e}")

    print(f"Bot pronto — logado como {bot.user} (ID: {bot.user.id})")

# ...restante do bot (comandos /config, /criar, etc.) continua aqui...

if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)