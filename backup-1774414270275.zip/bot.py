#!/usr/bin/env python3
# Bot FF Salas — bot.py (com persistência de rooms_history, total_rooms_created e created_rooms (seguro))
# Atualizado: integrações, correções e ajuste de intervalos (1->4s,2->6s,3->9s)
import os
import json
import time
import asyncio
import random
import traceback
from typing import Optional, Dict, List, Tuple, Any
from datetime import datetime, timezone, timedelta

import aiohttp
import discord
from discord import app_commands, SelectOption
from discord.ui import View, Button, Modal, TextInput, Select
from dotenv import load_dotenv

load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
API_BASE = os.getenv("API_BASE", "https://salas-bot.freefireapi.online")
KEY_FILE = os.getenv("KEY_FILE", "keys.json")
SETTINGS_FILE = os.getenv("SETTINGS_FILE", "settings.json")
STATE_FILE = os.getenv("STATE_FILE", "state.json")

# Contagem do embed (aceita 1 ou 2; default 1)
try:
    COUNTDOWN_INTERVAL = int(os.getenv("COUNTDOWN_INTERVAL", "1"))
    if COUNTDOWN_INTERVAL not in (1, 2):
        COUNTDOWN_INTERVAL = 1
except Exception:
    COUNTDOWN_INTERVAL = 1

# Intervalo padrão do config updater — index (1,2,3) -> seconds mapping below
try:
    UPDATE_INTERVAL = int(os.getenv("UPDATE_INTERVAL", "1"))
    if UPDATE_INTERVAL not in (1, 2, 3):
        UPDATE_INTERVAL = 1
except Exception:
    UPDATE_INTERVAL = 1

# Map old choices (1,2,3) -> seconds: changed per request from (2,4,6) to (4,6,9)
UPDATE_INTERVAL_SECONDS = {
    1: 4,
    2: 6,
    3: 9
}

# Dev IDs CSV (default)
DEV_IDS_ENV = os.getenv("DEV_IDS", "1360285479085412363,1118625635552727161,1198497156881977459").strip()
GUILD_IDS_ENV = os.getenv("GUILD_IDS", "").strip()

def _parse_id_list(raw: str) -> List[int]:
    if not raw:
        return []
    out = []
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out.append(int(part))
        except ValueError:
            pass
    return out

DEV_IDS = _parse_id_list(DEV_IDS_ENV)
GUILD_IDS = _parse_id_list(GUILD_IDS_ENV)

if not DISCORD_TOKEN:
    raise SystemExit("ERRO: defina DISCORD_TOKEN nas variáveis de ambiente")

intents = discord.Intents.default()
bot = discord.Client(intents=intents)
tree = app_commands.CommandTree(bot)

last_create_by_key: Dict[str, float] = {}

# In-memory map of created rooms (runtime only)
created_rooms: Dict[str, dict] = {}

# rooms_history used for top-N queries (persisted)
rooms_history: List[dict] = []

# Global in-memory counter of total rooms created since bot start (persisted)
total_rooms_created = 0

# Shared aiohttp session (to avoid "Unclosed client session")
_shared_http_session: Optional[aiohttp.ClientSession] = None

async def get_shared_session() -> aiohttp.ClientSession:
    global _shared_http_session
    if _shared_http_session is None or _shared_http_session.closed:
        _shared_http_session = aiohttp.ClientSession()
    return _shared_http_session

async def close_shared_session():
    global _shared_http_session
    try:
        if _shared_http_session and not _shared_http_session.closed:
            await _shared_http_session.close()
    except Exception:
        pass
    _shared_http_session = None

# --- Simple JSON storage helpers ---
def load_json(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_json(path: str, data: dict) -> None:
    tmp = f"{path}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except Exception:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

# --- State persistence ---
def load_state():
    global rooms_history, total_rooms_created, created_rooms
    state = load_json(STATE_FILE)
    if not isinstance(state, dict):
        return
    rh = state.get("rooms_history")
    tr = state.get("total_rooms_created")
    cr = state.get("created_rooms")
    if isinstance(rh, list):
        rooms_history = rh
    if isinstance(tr, int):
        total_rooms_created = tr
    if isinstance(cr, dict):
        try:
            created_rooms = {}
            for rid, info in cr.items():
                created_rooms[str(rid)] = {
                    "owner_id": info.get("owner_id"),
                    "roomId": info.get("roomId", str(rid)),
                    "senha": info.get("senha"),
                    "modo_text": info.get("modo_text"),
                    "created_at": info.get("created_at"),
                    "total_seconds": info.get("total_seconds"),
                    "key_masked": info.get("key_masked"),
                    "usos_antes": info.get("usos_antes"),
                    "usos_depois": info.get("usos_depois"),
                    "sshash": "",
                    "message": None,
                    "used_key": None,
                    "auto_end": None,
                    "updater_task": None,
                    "started": False
                }
        except Exception:
            created_rooms = {}
    print(f"[state] Loaded: {len(rooms_history)} history entries, total_rooms_created={total_rooms_created}, created_rooms={len(created_rooms)}")

def save_state():
    safe_created = {}
    for rid, info in created_rooms.items():
        try:
            safe_created[str(rid)] = {
                "owner_id": info.get("owner_id"),
                "roomId": info.get("roomId"),
                "senha": info.get("senha"),
                "modo_text": info.get("modo_text"),
                "created_at": info.get("created_at"),
                "total_seconds": info.get("total_seconds"),
                "key_masked": info.get("key_masked"),
                "usos_antes": info.get("usos_antes"),
                "usos_depois": info.get("usos_depois"),
            }
        except Exception:
            continue

    state = {
        "rooms_history": rooms_history,
        "total_rooms_created": total_rooms_created,
        "created_rooms": safe_created
    }
    save_json(STATE_FILE, state)
    print(f"[state] Saved: {len(rooms_history)} history entries, total_rooms_created={total_rooms_created}, created_rooms={len(safe_created)}")

_autosave_task: Optional[asyncio.Task] = None
_presence_task: Optional[asyncio.Task] = None

async def _autosave_state_task(interval: int = 30):
    try:
        while True:
            await asyncio.sleep(interval)
            try:
                save_state()
            except Exception:
                pass
    except asyncio.CancelledError:
        return

# --- Keys helpers ---
def get_user_keys(user_id: int) -> List[str]:
    data = load_json(KEY_FILE)
    val = data.get(str(user_id))
    if val is None:
        return []
    if isinstance(val, list):
        return [v for v in val if isinstance(v, str)]
    if isinstance(val, str):
        return [val]
    return []

def add_user_key(user_id: int, key: str) -> None:
    data = load_json(KEY_FILE)
    cur = data.get(str(user_id))
    if cur is None:
        data[str(user_id)] = [key]
    elif isinstance(cur, list):
        if key not in cur:
            cur.append(key)
            data[str(user_id)] = cur
    elif isinstance(cur, str):
        if cur != key:
            data[str(user_id)] = [cur, key]
    else:
        data[str(user_id)] = [key]
    save_json(KEY_FILE, data)

def remove_user_key(user_id: int, key: str) -> None:
    data = load_json(KEY_FILE)
    cur = data.get(str(user_id))
    if cur is None:
        return
    if isinstance(cur, list):
        if key in cur:
            cur.remove(key)
            data[str(user_id)] = cur
    elif isinstance(cur, str):
        if cur == key:
            data.pop(str(user_id), None)
    save_json(KEY_FILE, data)

def get_primary_user_key(user_id: int) -> Optional[str]:
    keys = get_user_keys(user_id)
    return keys[0] if keys else None

def get_user_settings(user_id: int) -> dict:
    settings = load_json(SETTINGS_FILE)
    return settings.get(str(user_id), {})

def set_user_setting(user_id: int, k: str, v) -> None:
    settings = load_json(SETTINGS_FILE)
    user = settings.setdefault(str(user_id), {})
    user[k] = v
    save_json(SETTINGS_FILE, settings)

# --- Utils ---
def _format_seconds(sec: Optional[int]) -> str:
    if sec is None:
        return "—"
    m = sec // 60
    s = sec % 60
    return f"{m:02d}:{s:02d}"

def _utc_now_str():
    return datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M:%S UTC")

def _mask_key(k: str) -> str:
    if not k or len(k) < 10:
        return k or "—"
    return f"{k[:8]}...{k[-4:]}"

def _format_player_entry(p: Any) -> str:
    nickname = None
    platform_tag = ""
    try:
        if isinstance(p, dict):
            for k in ("nickname", "nick", "name", "username", "playerName", "playerID", "account", "user"):
                if k in p and isinstance(p[k], (str, int)):
                    nickname = str(p[k])
                    break
            if "playerPlatform" in p and isinstance(p["playerPlatform"], (str, int)):
                pf = str(p["playerPlatform"]).lower()
                if "emu" in pf or "pc" in pf or "emulator" in pf:
                    platform_tag = "EMU"
                elif any(x in pf for x in ("mobile", "android", "ios", "phone")):
                    platform_tag = "MOBILE"
            if not platform_tag:
                for k in ("device", "platform", "client", "clientType", "deviceType", "type", "platform_type", "device_info", "client_info"):
                    if k in p:
                        v = p[k]
                        if isinstance(v, (str, int)):
                            vstr = str(v).lower()
                            if any(sub in vstr for sub in ("emu", "emul", "emulator", "pc", "tencent")):
                                platform_tag = "EMU"
                                break
                            if any(sub in vstr for sub in ("mobile", "android", "ios", "phone")):
                                platform_tag = "MOBILE"
                                break
                        if isinstance(v, bool):
                            if k.lower().startswith("is") and v:
                                if "emu" in k.lower() or "emul" in k.lower():
                                    platform_tag = "EMU"
                                elif "mobile" in k.lower():
                                    platform_tag = "MOBILE"
            for flag in ("is_emulator", "is_emulated", "emu", "emulator"):
                if flag in p and p.get(flag):
                    platform_tag = "EMU"
                    break
        else:
            nickname = str(p)
    except Exception:
        try:
            nickname = str(p)
        except Exception:
            nickname = "player"
    if not nickname:
        nickname = "player"
    tag = f" ({platform_tag})" if platform_tag else ""
    return f"{nickname}{tag}"

# --- HTTP helpers using shared session ---
async def _try_get(session: aiohttp.ClientSession, method: str, url: str, *, params=None, headers=None, json_body=None, timeout=8):
    """
    Wrapper that uses provided session (should be shared) and returns parsed JSON or None.
    """
    try:
        if method == "GET":
            async with session.get(url, params=params, headers=headers, timeout=timeout) as r:
                try:
                    return await r.json()
                except Exception:
                    return None
        else:
            async with session.post(url, json=json_body, headers=headers, timeout=timeout) as r:
                try:
                    return await r.json()
                except Exception:
                    return None
    except Exception:
        return None

# debug POST helper (returns json, status, text)
async def _post_with_debug(session: aiohttp.ClientSession, url: str, json_body: dict, headers: dict, timeout: int = 10):
    try:
        async with session.post(url, json=json_body, headers=headers, timeout=timeout) as r:
            status = r.status
            text = await r.text()
            try:
                data = await r.json()
            except Exception:
                data = {"_raw_text": text}
            return data, status, text
    except Exception as e:
        return {"error": str(e)}, None, str(e)

# --- API operations ---
async def create_room_with_key(key: str, payload: dict) -> dict:
    now = time.time()
    last = last_create_by_key.get(key, 0)
    elapsed = now - last
    if elapsed < 1.2:
        await asyncio.sleep(1.2 - elapsed)
    headers = {"Authorization": key, "Content-Type": "application/json"}
    session = await get_shared_session()
    try:
        async with session.post(f"{API_BASE}/api/v1/create:room", json=payload, headers=headers, timeout=15) as r:
            last_create_by_key[key] = time.time()
            try:
                data = await r.json()
            except Exception:
                data = {"status": "ERRO", "msg": f"Resposta inesperada ({r.status})"}
    except Exception as e:
        data = {"status": "ERRO", "msg": str(e)}
    try:
        print(f"[create_room] key_mask={_mask_key(key)} payload={payload} resp_keys={list(data.keys()) if isinstance(data, dict) else type(data)}")
    except Exception:
        pass
    return data

async def verificar_key_info(key: str) -> dict:
    session = await get_shared_session()
    try:
        async with session.get(f"{API_BASE}/api/verificar-key", params={"oauth_key": key}, timeout=10) as r:
            try:
                return await r.json()
            except Exception:
                return {}
    except Exception:
        return {}

async def start_room(sshash: str, key: str, enviar_msg: Optional[bool] = True) -> dict:
    if not sshash:
        return {"status": "ERRO", "msg": "sshash ausente"}
    headers = {"Authorization": key, "Content-Type": "application/json"}
    payload = {"sshash": sshash}
    if enviar_msg is not None:
        payload["enviar_msg"] = bool(enviar_msg)
    session = await get_shared_session()
    try:
        async with session.post(f"{API_BASE}/api/v2/start:room", json=payload, headers=headers, timeout=12) as r:
            try:
                return await r.json()
            except Exception:
                return {"status": "ERRO", "msg": f"Resposta inesperada ({r.status})"}
    except Exception as e:
        return {"status": "ERRO", "msg": str(e)}

def _is_start_success(resp: Optional[dict]) -> bool:
    if not isinstance(resp, dict):
        return False
    try:
        status = str(resp.get("status", "")).upper()
    except Exception:
        status = ""
    if status in ("PARTIDA_INICIADA", "SUCCESS", "OK", "STARTED"):
        return True
    msg = str(resp.get("msg", "")).lower()
    if any(sub in msg for sub in ("já foi iniciada", "ja foi iniciada", "partida ja", "already started", "already begun", "partida já")):
        return True
    if str(resp.get("success", "")).lower() in ("ok", "true", "1"):
        return True
    return False

def choose_display_id_from_resp(resp: dict) -> Tuple[str, Optional[str]]:
    if not isinstance(resp, dict):
        return ("—", None)
    sshash = resp.get("sshash") or resp.get("hash") or resp.get("ss_hash")
    for k in ("id", "roomId", "room_id", "roomNumber", "room"):
        if k in resp:
            v = resp.get(k)
            if isinstance(v, int) or (isinstance(v, str) and str(v).isdigit()):
                return (str(v), sshash)
    def _find_numeric(obj: Any) -> Optional[str]:
        if obj is None:
            return None
        if isinstance(obj, dict):
            for k in ("id", "roomId", "room_id", "roomNumber", "room"):
                if k in obj:
                    v = obj.get(k)
                    if isinstance(v, int) or (isinstance(v, str) and str(v).isdigit()):
                        return str(v)
            for v in obj.values():
                res = _find_numeric(v)
                if res:
                    return res
        elif isinstance(obj, list):
            for item in obj:
                res = _find_numeric(item)
                if res:
                    return res
        else:
            if isinstance(obj, int):
                return str(obj)
            if isinstance(obj, str) and obj.isdigit():
                return obj
        return None
    nested_num = _find_numeric(resp)
    if nested_num:
        return (nested_num, sshash)
    for k, v in resp.items():
        if isinstance(v, int) or (isinstance(v, str) and str(v).isdigit()):
            return (str(v), sshash)
    if sshash:
        return (str(sshash), sshash)
    return ("—", sshash)

# --- Fetch status: tries endpoints and normalizes players (sends oauth_key) ---
async def fetch_room_status_candidates(sshash: str, key: Optional[str]) -> Optional[dict]:
    """
    Faz GET/POST nos endpoints conhecidos, enviando oauth_key quando disponível.
    Retorna dict com 'team1' e 'team2' (cada um lista de objects/raw entries) ou {'raw': res}.
    Imprime logs reduzidos para diagnóstico.
    """
    headers = {}
    if key:
        headers["Authorization"] = key

    candidates = [
        ("GET", f"{API_BASE}/api/v2/info:room"),
        ("GET", f"{API_BASE}/api/v2/room"),
        ("GET", f"{API_BASE}/api/v1/room"),
        ("GET", f"{API_BASE}/api/v1/room:info"),
        ("GET", f"{API_BASE}/api/room"),
        ("GET", f"{API_BASE}/api/room/info"),
        ("POST", f"{API_BASE}/api/v2/info:room"),
        ("POST", f"{API_BASE}/api/v2/room"),
        ("POST", f"{API_BASE}/api/v1/room"),
        ("POST", f"{API_BASE}/api/room"),
    ]

    session = await get_shared_session()
    for method, url in candidates:
        try:
            if method == "GET":
                params = {"sshash": sshash, "roomId": sshash}
                if key:
                    params["oauth_key"] = key
                res = await _try_get(session, "GET", url, params=params, headers=headers)
            else:
                json_body = {"sshash": sshash, "roomId": sshash}
                if key:
                    json_body["oauth_key"] = key
                res = await _try_get(session, "POST", url, json_body=json_body, headers=headers)
        except Exception:
            res = None

        if not res or not isinstance(res, dict):
            continue

        # debug
        try:
            print(f"[fetch_room] endpoint={url} method={method} key_mask={_mask_key(key)} resp_keys={list(res.keys())}")
        except Exception:
            pass

        # 1) infoGroups (v2/info:room)
        if "infoGroups" in res and isinstance(res["infoGroups"], list):
            try:
                team1 = []
                team2 = []
                for group in res["infoGroups"]:
                    if not isinstance(group, dict):
                        continue
                    idx = group.get("teamIndex")
                    players = group.get("players") or group.get("members") or []
                    if isinstance(players, list):
                        try:
                            if int(idx) == 1:
                                team1.extend(players)
                            elif int(idx) == 2:
                                team2.extend(players)
                            else:
                                if not team1:
                                    team1.extend(players)
                                else:
                                    team2.extend(players)
                        except Exception:
                            if not team1:
                                team1.extend(players)
                            else:
                                team2.extend(players)
                return {"team1": team1, "team2": team2, "raw": res}
            except Exception:
                pass

        # 2) direct named lists
        possible_lists = []
        for k in ("team1", "time1", "left", "players_left", "team_left", "time_left",
                  "team2", "time2", "right", "players_right", "team_right", "time_right"):
            if k in res and isinstance(res[k], list):
                possible_lists.append((k, res[k]))

        if possible_lists:
            left = []
            right = []
            for k, lst in possible_lists:
                if any(x in k for x in ("team2", "time2", "right", "players_right", "team_right")):
                    right.extend(lst)
                else:
                    left.extend(lst)
            return {"team1": left, "team2": right, "raw": res}

        # 3) teams array (teams -> players/members)
        if "teams" in res and isinstance(res["teams"], list):
            try:
                t0 = res["teams"][0] if len(res["teams"]) > 0 else None
                t1 = res["teams"][1] if len(res["teams"]) > 1 else None
                team1 = []
                team2 = []
                if isinstance(t0, dict):
                    for pk in ("players", "members", "users"):
                        if pk in t0 and isinstance(t0[pk], list):
                            team1 = t0[pk]
                            break
                if isinstance(t1, dict):
                    for pk in ("players", "members", "users"):
                        if pk in t1 and isinstance(t1[pk], list):
                            team2 = t1[pk]
                            break
                if team1 or team2:
                    return {"team1": team1 or [], "team2": team2 or [], "raw": res}
            except Exception:
                pass

        # 4) players list with per-player team field
        if "players" in res and isinstance(res["players"], list):
            left = []
            right = []
            for p in res["players"]:
                try:
                    team = None
                    if isinstance(p, dict):
                        for tk in ("team", "side", "slot"):
                            if tk in p:
                                team = p[tk]
                                break
                    if team in (1, "1", "left", "L", "left_side"):
                        left.append(p)
                    elif team in (2, "2", "right", "R", "right_side"):
                        right.append(p)
                    else:
                        left.append(p)
                except Exception:
                    continue
            if left or right:
                return {"team1": left, "team2": right, "raw": res}

        # 5) nested fields (data/result/payload/info)
        for parent in ("data", "result", "payload", "info"):
            p = res.get(parent)
            if isinstance(p, dict):
                for pk in ("players", "members", "participants", "users"):
                    if pk in p and isinstance(p[pk], list):
                        arr = p[pk]
                        left = []
                        right = []
                        for item in arr:
                            try:
                                if isinstance(item, dict):
                                    team = item.get("team") or item.get("side") or item.get("slot")
                                    if team in (2, "2", "right", "R"):
                                        right.append(item)
                                    else:
                                        left.append(item)
                                else:
                                    left.append(item)
                            except Exception:
                                left.append(item)
                        return {"team1": left, "team2": right, "raw": res}

        # 6) counts fallback
        for k in ("count_left", "left_count", "team1_count", "time1_count", "leftPlayersCount"):
            if k in res:
                return {"team1": [], "team2": [], "counts": res, "raw": res}

        # 7) raw
        return {"raw": res}

    return None

# --- Expel helpers (per API doc) ---
def _is_expel_success(resp: Optional[dict]) -> bool:
    if not isinstance(resp, dict):
        return False
    try:
        status = str(resp.get("status", "")).upper()
    except Exception:
        status = ""
    if status == "EXPULSO":
        return True
    if str(resp.get("success", "")).lower() in ("ok", "true", "1"):
        return True
    msg = str(resp.get("msg", "")).lower()
    if any(x in msg for x in ("expul", "kicked", "remov", "kick", "retirado")):
        return True
    return False

async def expel_player(sshash: str, account_id: str, key: Optional[str]) -> Tuple[bool, dict]:
    """
    Prioriza os endpoints documentados e envia payload {"sshash":..., "accountid": <number>}.
    Retorna (success, debug_info_or_response).
    """
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = key

    endpoints = [
        f"{API_BASE}/api/v2/expulsar-player",
        f"{API_BASE}/api/v1/expulsar-player",
        f"{API_BASE}/api/v2/room/expel",
        f"{API_BASE}/api/v1/room/expel",
        f"{API_BASE}/api/v2/expel",
        f"{API_BASE}/api/v1/expel",
    ]

    # normalize: keep only digits
    acct_digits = "".join(ch for ch in (account_id or "") if ch.isdigit())
    if not acct_digits:
        return False, {"error": "accountid inválido (precisa conter dígitos)", "provided": account_id}
    try:
        acct_num = int(acct_digits)
    except Exception:
        acct_num = acct_digits

    payload = {"sshash": sshash, "accountid": acct_num}

    session = await get_shared_session()
    last_debug = None
    for url in endpoints:
        try:
            resp_json, status, text = await _post_with_debug(session, url, payload, headers)
        except Exception as e:
            resp_json, status, text = {"error": str(e)}, None, str(e)

        last_debug = {"url": url, "status": status, "resp_json": resp_json, "text_snippet": (text[:800] if isinstance(text, str) else None)}
        try:
            print(f"[expel_try] url={url} status={status} key_mask={_mask_key(key)} resp_keys={list(resp_json.keys()) if isinstance(resp_json, dict) else type(resp_json)}")
        except Exception:
            pass

        if _is_expel_success(resp_json):
            return True, {"url": url, "status": status, "resp": resp_json}

    return False, {"error": "nenhum endpoint respondeu com sucesso", "last": last_debug}

# --- Small helper to extract usos from verificar-key responses ---
def _extract_usos(info: dict):
    if not isinstance(info, dict):
        return None
    for candidate in ("usos_restantes", "usos", "uses", "remaining", "remaining_uses", "usosRestantes"):
        if candidate in info:
            return info.get(candidate)
    for parent in ("data", "result", "payload"):
        p = info.get(parent)
        if isinstance(p, dict):
            for candidate in ("usos_restantes", "usos", "uses", "remaining", "remaining_uses"):
                if candidate in p:
                    return p.get(candidate)
    return None

# --- Modals & Commands below ---
class KeyModal(Modal, title="Resgatar / Registrar Key"):
    key = TextInput(label="Sua oauth_key (SALABOT-...)", placeholder="SALABOT-ABCD1234...", max_length=256)
    def __init__(self, user_id: int):
        super().__init__()
        self.user_id = user_id
    async def on_submit(self, interaction: discord.Interaction):
        raw = self.key.value.strip()
        if not raw:
            await interaction.response.send_message("❌ Key vazia.", ephemeral=True)
            return
        try:
            add_user_key(self.user_id, raw)
            info = await verificar_key_info(raw)
            try:
                print(f"[verificar_key] user={self.user_id} key_mask={_mask_key(raw)} info_keys={list(info.keys()) if isinstance(info, dict) else None}")
            except Exception:
                pass
            usos = None
            try:
                usos = _extract_usos(info)
            except Exception:
                usos = None
            usos_txt = str(usos) if usos is not None else "—"
            await interaction.response.send_message(f"✅ Key adicionada com sucesso (privado).\n📊 Usos restantes: {usos_txt}", ephemeral=True)
        except Exception as e:
            print(f"[KeyModal] erro ao resgatar key: {e}")
            await interaction.response.send_message("❌ Algo deu errado ao registrar a key. Tente novamente.", ephemeral=True)

class SenhaModal(Modal, title="Definir Senha Fixa"):
    senha = TextInput(label="Senha numérica (apenas dígitos)", placeholder="Ex: 1234", max_length=8)
    def __init__(self, user_id: int):
        super().__init__()
        self.user_id = user_id
    async def on_submit(self, interaction: discord.Interaction):
        raw = self.senha.value.strip()
        if not raw.isdigit():
            await interaction.response.send_message("❌ Senha inválida: apenas dígitos.", ephemeral=True)
            return
        set_user_setting(self.user_id, "senha_fixa", raw)
        await interaction.response.send_message("✅ Senha fixa salva (privado).", ephemeral=True)

class TimerModal(Modal, title="Configurar Timer (auto_start)"):
    minutes = TextInput(label="Auto start (minutos, 1-8)", placeholder="Ex: 5", max_length=2)
    def __init__(self, user_id: int):
        super().__init__()
        self.user_id = user_id
    async def on_submit(self, interaction: discord.Interaction):
        raw = self.minutes.value.strip()
        if not raw.isdigit():
            await interaction.response.send_message("❌ Valor inválido.", ephemeral=True)
            return
        val = int(raw)
        if not (1 <= val <= 8):
            await interaction.response.send_message("❌ Valor inválido: 1-8 minutos.", ephemeral=True)
            return
        set_user_setting(self.user_id, "auto_start", val)
        await interaction.response.send_message(f"✅ Auto start salvo: {val} minuto(s).", ephemeral=True)

class DaysModal(Modal, title="Top 3 — Intervalo (dias)"):
    days = TextInput(label="Número de dias", placeholder="Ex: 7", max_length=5)
    def __init__(self, user_id: int):
        super().__init__()
        self.user_id = user_id
    async def on_submit(self, interaction: discord.Interaction):
        raw = self.days.value.strip()
        if not raw.isdigit():
            await interaction.response.send_message("❌ Valor inválido: digite apenas números.", ephemeral=True)
            return
        days = int(raw)
        if days <= 0:
            await interaction.response.send_message("❌ Valor inválido: informe um número maior que 0.", ephemeral=True)
            return
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        counts: Dict[int, int] = {}
        for rec in rooms_history:
            try:
                dt = datetime.fromisoformat(rec.get("created_at"))
            except Exception:
                continue
            if dt >= cutoff:
                owner = rec.get("owner_id")
                counts[owner] = counts.get(owner, 0) + 1
        top = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:3]
        emb = discord.Embed(title=f"Top 3 criadores (últimos {days} dias) — Dev (privado)", color=0xFFD166)
        if not top:
            emb.description = "Nenhuma sala criada nesse período."
            await interaction.response.send_message(embed=emb, ephemeral=True)
            return
        lines = []
        for idx, (owner_id, cnt) in enumerate(top, start=1):
            user = bot.get_user(owner_id)
            if user:
                label = f"{user.display_name} ({owner_id})"
            else:
                label = str(owner_id)
            lines.append(f"{idx}. {label} — {cnt} sala(s)")
        emb.add_field(name="Top 3", value="\n".join(lines), inline=False)
        await interaction.response.send_message(embed=emb, ephemeral=True)

class ExpelModal(Modal, title="Expulsar Jogador — accountId"):
    account_id = TextInput(label="Account ID do jogador", placeholder="Ex: 1234567890 ou account_xxx", max_length=128)

    def __init__(self, roomId: str, owner_id: int):
        super().__init__()
        self.roomId = roomId
        self.owner_id = owner_id

    async def on_submit(self, interaction: discord.Interaction):
        # only room owner can expel
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("❌ Apenas o criador da sala pode expulsar jogadores.", ephemeral=True)
            return

        acc = self.account_id.value.strip()
        if not acc:
            await interaction.response.send_message("❌ accountId vazio.", ephemeral=True)
            return

        # lookup room info
        room_info = created_rooms.get(str(self.roomId))
        if not room_info:
            await interaction.response.send_message("❌ Sala não encontrada/expirada.", ephemeral=True)
            return

        sshash = room_info.get("sshash") or str(self.roomId)
        used_key = room_info.get("used_key")

        await interaction.response.defer(ephemeral=True, thinking=True)
        success, resp = await expel_player(str(sshash), acc, used_key)
        if success:
            await interaction.followup.send(f"✅ Jogador {acc} expulso com sucesso (ou pedido aceito pela API).", ephemeral=True)
        else:
            await interaction.followup.send(f"❌ Falha ao expulsar {acc}. Resposta: {resp}", ephemeral=True)

# --- Criar command / view ---
MODOS = {
    "1": "sem carregamento",
    "2": "com equipamento",
    "3": "1x1 gel inf",
    "4": "full capa",
    "5": "capa nv3 sem carreg"
}

class CriarSelect(Select):
    def __init__(self, user_id: int):
        options = [SelectOption(label=f"{k} - {v}", value=k) for k, v in MODOS.items()]
        super().__init__(placeholder="Escolha o modo da sala...", min_values=1, max_values=1, options=options, custom_id=f"criar_select_{user_id}")
        self.user_id = user_id

    async def callback(self, interaction: discord.Interaction):
        global total_rooms_created, rooms_history
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Apenas o usuário que abriu este menu pode usá-lo.", ephemeral=True)
            return

        await interaction.response.defer(thinking=True, ephemeral=True)
        modo = int(self.values[0])

        keys = get_user_keys(self.user_id)
        if not keys:
            await interaction.followup.send("❌ Você não tem nenhuma key registrada. Use /config → Resgatar Key.", ephemeral=True)
            return

        settings = get_user_settings(self.user_id)
        payload = {"modo": modo}
        if settings.get("senha_fixa"):
            payload["senha"] = settings["senha_fixa"]
        payload["nome"] = settings.get("nome", f"Salinha{int(time.time())%10000}")
        if settings.get("auto_start"):
            payload["auto_start"] = settings.get("auto_start")

        last_error = None
        used_key = None
        resp = None
        usos_antes = None
        usos_depois = None

        # ==== CRITICAL CHANGE: robust create loop with timeout & logs ====
        for key in keys:
            try:
                print(f"[criar] tentando criar sala com key_mask={_mask_key(key)} payload_modo={modo}")
                info_before = await verificar_key_info(key)
                usos_antes = _extract_usos(info_before)
            except Exception:
                usos_antes = None

            try:
                # coloque timeout curto (20s) para evitar hang indefinido
                resp = await asyncio.wait_for(create_room_with_key(key, payload), timeout=20)
            except asyncio.TimeoutError:
                print(f"[criar] timeout ao chamar create_room_with_key para key_mask={_mask_key(key)}")
                last_error = {"status": "ERRO", "msg": "timeout ao chamar API (create_room)"}
                continue
            except Exception as e:
                print(f"[criar] erro ao chamar create_room_with_key key_mask={_mask_key(key)}: {e}")
                last_error = {"status": "ERRO", "msg": str(e)}
                continue

            if not isinstance(resp, dict):
                print(f"[criar] resposta inesperada (não-dict) create_room_with_key: {type(resp)}")
                last_error = {"status": "ERRO", "msg": "resposta inesperada da API"}
                continue

            status = str(resp.get("status", "") or "").upper()
            print(f"[criar] resposta create_room_with_key key_mask={_mask_key(key)} status={status} keys={list(resp.keys()) if isinstance(resp, dict) else None}")

            if status == "SALA_CRIADA":
                used_key = key
                break

            last_error = resp
        # ==== end create loop ====

        if not used_key:
            await interaction.followup.send(f"❌ Falha ao criar sala com todas as suas keys: {last_error}", ephemeral=True)
            return

        display_id, sshash = choose_display_id_from_resp(resp)
        sshash = sshash or resp.get("sshash", "")
        roomId = display_id or (resp.get("roomId") or resp.get("id") or "—")
        senha = resp.get("senha", payload.get("senha", "—"))
        modo_text = MODOS.get(str(modo), f"Modo {modo}")
        info_after = await verificar_key_info(used_key)
        usos_depois = _extract_usos(info_after)
        auto_start_min = settings.get("auto_start")
        total_seconds = auto_start_min * 60 if auto_start_min else None
        title = "🚀 Partida iniciada (auto start)" if auto_start_min else "✅ Sala Criada com Sucesso!"
        embed = discord.Embed(title=title, color=0x22C55E)
        embed.add_field(name="🆔 ID", value=str(roomId), inline=True)
        embed.add_field(name="🔐 Senha", value=str(senha), inline=True)
        embed.add_field(name="🎮 Modo", value=str(modo_text), inline=True)
        embed.add_field(name="⏱️ Auto start", value="iniciada" if total_seconds else "Nenhum", inline=True)

        key_masked = _mask_key(used_key)
        usos_antes_txt = str(usos_antes) if usos_antes is not None else "—"
        usos_depois_txt = str(usos_depois) if usos_depois is not None else "—"
        embed.add_field(name="🔻", value="Menos 1 sala descontada da sua key.", inline=False)
        embed.add_field(name="🔑 Key", value=f"{key_masked}", inline=True)
        embed.add_field(name="📊 Usos (antes → depois)", value=f"{usos_antes_txt} → {usos_depois_txt}", inline=True)

        embed.add_field(name="👥 Time 1 (Esquerda)", value="Sem jogadores", inline=True)
        embed.add_field(name="👥 Time 2 (Direita)", value="Sem jogadores", inline=True)
        embed.add_field(name="Criada em", value=_utc_now_str(), inline=False)

        created_rooms[str(roomId)] = {
            "owner_id": self.user_id,
            "roomId": str(roomId),
            "senha": str(senha),
            "modo_text": modo_text,
            "created_at": _utc_now_str(),
            "total_seconds": total_seconds,
            "key_masked": key_masked,
            "usos_antes": usos_antes_txt,
            "usos_depois": usos_depois_txt,
            "sshash": sshash or "",
            "used_key": used_key,
            "auto_end": None,
            "updater_task": None,
            "started": False,
            "message": None
        }

        rooms_history.append({
            "owner_id": self.user_id,
            "roomId": str(roomId),
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        total_rooms_created += 1
        try:
            save_state()
        except Exception:
            pass

        # update presence asap (immediate)
        try:
            asyncio.create_task(_update_presence_once())
        except Exception:
            pass

        try:
            # ensure presence loop is running with configured seconds mapping
            interval_seconds = UPDATE_INTERVAL_SECONDS.get(UPDATE_INTERVAL, 4)
            if _presence_task is None or (_presence_task and _presence_task.done()):
                asyncio.create_task(update_presence_loop(interval=interval_seconds))
        except Exception:
            pass

        view = discord.ui.View(timeout=None)
        btn_sep = Button(label="Enviar Separado (ID / Senha)", style=discord.ButtonStyle.secondary)
        btn_junto = Button(label="Enviar ID+Senha", style=discord.ButtonStyle.secondary)
        btn_copy = Button(label="Copiar ID (privado)", style=discord.ButtonStyle.secondary)
        btn_expulsar = Button(label="Expulsar Jogadores", style=discord.ButtonStyle.secondary)
        btn_go = Button(label="Go (Iniciar Sala)", style=discord.ButtonStyle.success)

        async def _check_owner(inter: discord.Interaction) -> bool:
            if inter.user.id != self.user_id:
                await inter.response.send_message("❌ Apenas o criador pode usar este botão.", ephemeral=True)
                return False
            return True

        async def enviar_sep_callback(inter: discord.Interaction):
            if not await _check_owner(inter): return
            await inter.response.send_message(f"ID: {roomId}\nSenha: {senha}", ephemeral=True)
        btn_sep.callback = enviar_sep_callback

        async def enviar_junto_callback(inter: discord.Interaction):
            if not await _check_owner(inter): return
            await inter.response.send_message(f"{roomId} {senha}", ephemeral=True)
        btn_junto.callback = enviar_junto_callback

        async def copiar_callback(inter: discord.Interaction):
            if not await _check_owner(inter): return
            await inter.response.send_message(str(roomId), ephemeral=True)
        btn_copy.callback = copiar_callback

        # expulsar: abre select com players (usa a mesma parsing do embed)
        async def expulsar_button_cb(inter: discord.Interaction):
            if not await _check_owner(inter): return
            room_info = created_rooms.get(str(roomId), {})
            used_key_local = room_info.get("used_key")
            await _open_expel_select(inter, str(roomId), self.user_id, used_key_local)
        btn_expulsar.callback = expulsar_button_cb

        async def go_callback(inter: discord.Interaction):
            if not await _check_owner(inter): return
            await inter.response.defer(ephemeral=True, thinking=True)
            room_info = created_rooms.get(str(roomId), {})
            try:
                t = room_info.get("updater_task")
                if t and not t.done():
                    t.cancel()
            except Exception:
                pass
            sshash_local = room_info.get("sshash", "") or str(sshash or roomId)
            respjson = await start_room(sshash_local, used_key)
            if _is_start_success(respjson):
                room_info["started"] = True
            await inter.followup.send("✅ Partida iniciada com sucesso! (privado)", ephemeral=True)
            try:
                msg = inter.message
                if msg:
                    new_embed = discord.Embed(title="⚡ Partida Iniciada (privado)", description="A sala foi iniciada via botão Go.", color=0xF97316)
                    new_embed.add_field(name="🆔 ID", value=str(roomId), inline=True)
                    new_embed.add_field(name="🔐 Senha", value=str(senha), inline=True)
                    new_embed.add_field(name="🎮 Modo", value=str(modo_text), inline=True)
                    new_embed.add_field(name="Criada em", value=_utc_now_str(), inline=False)
                    try:
                        await msg.edit(embed=new_embed, view=None)
                    except Exception:
                        pass
            except Exception:
                pass

        btn_go.callback = go_callback

        view.add_item(btn_sep)
        view.add_item(btn_junto)
        view.add_item(btn_copy)
        view.add_item(btn_expulsar)
        view.add_item(btn_go)

        sent = await interaction.followup.send(embed=embed, view=view, ephemeral=True)
        created_rooms[str(roomId)]["message"] = sent

        try:
            if total_seconds:
                created_rooms[str(roomId)]["auto_end"] = time.time() + total_seconds
            created_rooms[str(roomId)]["updater_task"] = asyncio.create_task(_room_embed_updater(sent, str(roomId), interval=COUNTDOWN_INTERVAL))
        except Exception:
            pass

class CriarView(View):
    def __init__(self, user_id: int):
        super().__init__(timeout=None)
        self.add_item(CriarSelect(user_id))

# --- Helper to gather players for select (mirrors embed parsing) ---
def _gather_players_for_select(status: dict) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    if not status or not isinstance(status, dict):
        return out

    candidates = []
    # prefer explicit team arrays
    for key in ("team1", "team2", "players", "left", "right"):
        v = status.get(key)
        if isinstance(v, list):
            candidates.extend(v)

    # fallback: dig into raw
    raw = status.get("raw")
    if isinstance(raw, dict):
        # infoGroups
        if "infoGroups" in raw and isinstance(raw["infoGroups"], list):
            for g in raw["infoGroups"]:
                players = g.get("players") or g.get("members") or []
                if isinstance(players, list):
                    candidates.extend(players)
        # nested parents
        for parent in ("data", "result", "payload", "info"):
            p = raw.get(parent)
            if isinstance(p, dict):
                for pk in ("players", "members", "participants", "users"):
                    arr = p.get(pk)
                    if isinstance(arr, list):
                        candidates.extend(arr)
        # direct players field
        if "players" in raw and isinstance(raw["players"], list):
            candidates.extend(raw["players"])

    # normalize candidates -> extract account id + nickname label
    out_tmp: List[Tuple[str, str]] = []
    for item in candidates:
        try:
            account_id = None
            nickname_label = None
            if isinstance(item, dict):
                for aid_key in ("accountid", "accountId", "account_id", "playerID", "playerId", "id"):
                    if aid_key in item and item[aid_key] not in (None, ""):
                        account_id = str(item[aid_key])
                        break
                for nkey in ("nickname", "nick", "name", "username", "playerName", "playerID", "account", "user"):
                    if nkey in item and (item[nkey] not in (None, "")):
                        nickname_label = str(item[nkey])
                        break
                if not nickname_label:
                    if "playerID" in item and item.get("playerID"):
                        nickname_label = str(item.get("playerID"))
                if not nickname_label and account_id:
                    nickname_label = account_id
            else:
                nickname_label = str(item)
                account_id = None

            if not nickname_label:
                nickname_label = "player"

            if account_id:
                out_tmp.append((account_id, f"{nickname_label} — {account_id}"))
        except Exception:
            continue

    # dedupe preserving order
    seen = set()
    for aid, label in out_tmp:
        if aid in seen:
            continue
        seen.add(aid)
        out.append((aid, label))

    return out

# --- Helper: try to extract players directly from the message embed (fallback) ---
def _gather_players_from_message(msg_obj: Optional[discord.Message]) -> List[Tuple[str, str]]:
    """
    Quando a API não retornar players, tentamos extrair dos campos do embed que o bot já atualiza.
    Retorna lista de (account_id_or_label, label) tuples; quando não houver account id, usa label como valor.
    """
    out: List[Tuple[str, str]] = []
    try:
        if not msg_obj:
            return out
        embeds = getattr(msg_obj, "embeds", None)
        if not embeds:
            return out
        emb = embeds[0]  # assumimos primeiro embed
        # buscar campos com títulos esperados
        for field in emb.fields:
            name = (field.name or "").lower()
            if any(x in name for x in ("time 1", "time 2", "time", "players", "esquerda", "direita")):
                val = field.value or ""
                lines = [ln.strip() for ln in val.splitlines() if ln.strip()]
                for ln in lines:
                    # tentar extrair algo parecido com "nickname — 12345678"
                    if "—" in ln:
                        parts = [p.strip() for p in ln.rsplit("—", 1)]
                        if len(parts) == 2 and parts[1].isdigit():
                            out.append((parts[1], ln))
                            continue
                    # se ln contiver apenas dígitos (possível accountid)
                    digits = "".join(ch for ch in ln if ch.isdigit())
                    if digits and len(digits) >= 5:
                        out.append((digits, ln))
                        continue
                    # fallback: usar a linha inteira como label/valor
                    out.append((ln, ln))
    except Exception:
        pass

    # dedupe preserving order
    seen = set()
    uniq = []
    for aid, label in out:
        if aid in seen:
            continue
        seen.add(aid)
        uniq.append((aid, label))
    return uniq

# Select/flow to expel
class ExpelSelect(Select):
    def __init__(self, roomId: str, owner_id: int, used_key: Optional[str], players: List[Tuple[str,str]]):
        options = [SelectOption(label=label[:100], value=aid) for aid, label in players]
        custom_id = f"expel_select_{roomId}_{owner_id}"
        super().__init__(placeholder="Escolha o jogador para expulsar...", min_values=1, max_values=1, options=options, custom_id=custom_id)
        self.roomId = roomId
        self.owner_id = owner_id
        self.used_key = used_key

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("❌ Apenas o criador pode expulsar jogadores.", ephemeral=True)
            return

        account_id = self.values[0]
        await interaction.response.defer(ephemeral=True, thinking=True)

        room_info = created_rooms.get(str(self.roomId), {})
        sshash = room_info.get("sshash") or str(self.roomId)
        key = self.used_key or room_info.get("used_key")

        success, resp = await expel_player(str(sshash), account_id, key)
        if success:
            await interaction.followup.send(f"✅ Jogador {account_id} expulso com sucesso.", ephemeral=True)
        else:
            await interaction.followup.send(f"❌ Falha ao expulsar {account_id}. Resposta: {resp}", ephemeral=True)

        try:
            msg = created_rooms.get(str(self.roomId), {}).get("message")
            if msg:
                # trigger a one-shot updater to refresh immediately
                try:
                    asyncio.create_task(_room_embed_updater(msg, str(self.roomId), interval=1))
                except Exception:
                    pass
        except Exception:
            pass

async def _open_expel_select(inter: discord.Interaction, roomId: str, owner_id: int, used_key: Optional[str]):
    if inter.user.id != owner_id:
        await inter.response.send_message("❌ Apenas o criador pode usar este botão.", ephemeral=True)
        return

    await inter.response.defer(ephemeral=True, thinking=True)

    # preferir sshash salvo no created_rooms (senão usar roomId)
    room_info = created_rooms.get(str(roomId), {})
    sshash_to_use = room_info.get("sshash") or str(roomId)
    key_to_use = used_key or room_info.get("used_key")

    st = await fetch_room_status_candidates(str(sshash_to_use), key_to_use)

    # primeiro: tentar extrair players a partir da resposta da API
    players = _gather_players_for_select(st or {})

    # fallback: se API não retornou players, tentar extrair do embed da própria mensagem
    if not players:
        msg_obj = room_info.get("message")
        players = _gather_players_from_message(msg_obj)

    if not players:
        await inter.followup.send("❌ Nenhum jogador encontrado na sala (API não retornou players e não há dados no embed).", ephemeral=True)
        return

    view = discord.ui.View(timeout=60)
    sel = ExpelSelect(roomId, owner_id, key_to_use, players)
    view.add_item(sel)

    async def _cancel_cb(i: discord.Interaction):
        if i.user.id != owner_id:
            await i.response.send_message("❌ Apenas o criador pode usar este botão.", ephemeral=True)
            return
        try:
            await i.response.edit_message(content="Operação cancelada.", embed=None, view=None)
        except Exception:
            try:
                await i.response.send_message("Operação cancelada.", ephemeral=True)
            except Exception:
                pass
    btn_cancel = Button(label="Cancelar", style=discord.ButtonStyle.secondary)
    btn_cancel.callback = _cancel_cb
    view.add_item(btn_cancel)

    await inter.followup.send("Escolha o jogador para expulsar:", view=view, ephemeral=True)

# --- Updater for embed (keeps embed updated, auto-start) ---
async def _room_embed_updater(message: discord.Message, roomId: str, interval: int = 1):
    try:
        while True:
            room_info = created_rooms.get(str(roomId))
            if not room_info:
                return
            if room_info.get("started"):
                return
            msg_obj = room_info.get("message")
            if not msg_obj:
                return

            sshash = room_info.get("sshash") or str(roomId)
            used_key = room_info.get("used_key")
            senha = room_info.get("senha", "—")
            modo_text = room_info.get("modo_text", "—")
            key_masked = room_info.get("key_masked", "—")

            usos_txt = room_info.get("usos_depois", "—")
            if used_key:
                try:
                    info_key = await verificar_key_info(used_key)
                    usos = _extract_usos(info_key)
                    if usos is not None:
                        usos_txt = str(usos)
                        room_info["usos_depois"] = usos_txt
                except Exception:
                    pass

            team1_txt = "Sem jogadores"
            team2_txt = "Sem jogadores"
            try:
                st = await fetch_room_status_candidates(str(sshash), used_key)
                if st:
                    if isinstance(st.get("team1"), list):
                        if st.get("team1"):
                            players = [ _format_player_entry(x) for x in st["team1"][:50] ]
                            team1_txt = "\n".join(players) if players else "Sem jogadores"
                        else:
                            team1_txt = "Sem jogadores"
                    if isinstance(st.get("team2"), list):
                        if st.get("team2"):
                            players = [ _format_player_entry(x) for x in st["team2"][:50] ]
                            team2_txt = "\n".join(players) if players else "Sem jogadores"
                        else:
                            team2_txt = "Sem jogadores"
                    if team1_txt == "Sem jogadores" and st.get("counts"):
                        c = st["counts"]
                        team1_txt = str(c.get("team1") or c.get("left") or "Sem jogadores")
                    if team2_txt == "Sem jogadores" and st.get("counts"):
                        c = st["counts"]
                        team2_txt = str(c.get("team2") or c.get("right") or "Sem jogadores")
            except Exception:
                # fallback to embed content
                try:
                    msg_current = room_info.get("message")
                    if msg_current:
                        players_from_msg = _gather_players_from_message(msg_current)
                        if players_from_msg:
                            # split half/half if unknown teams
                            left = players_from_msg[:len(players_from_msg)//2 or 1]
                            right = players_from_msg[len(players_from_msg)//2 or 1:]
                            team1_txt = "\n".join([p[1] for p in left]) if left else "Sem jogadores"
                            team2_txt = "\n".join([p[1] for p in right]) if right else "Sem jogadores"
                except Exception:
                    pass

            remaining_txt = "Nenhum"
            auto_end = room_info.get("auto_end")
            if auto_end:
                remaining = int(max(0, int(auto_end - time.time())))
                remaining_txt = _format_seconds(remaining)

            try:
                emb = discord.Embed(title="✅ Sala Criada (privado)" if not room_info.get("started") else "⚡ Partida Iniciada (privado)",
                                    color=0x22C55E if not room_info.get("started") else 0xF97316)
                emb.add_field(name="🆔 ID", value=str(room_info.get("roomId", roomId)), inline=True)
                emb.add_field(name="🔐 Senha", value=str(senha), inline=True)
                emb.add_field(name="🎮 Modo", value=str(modo_text), inline=True)
                emb.add_field(name="⏱️ Auto start", value=(f"iniciada ({remaining_txt})" if auto_end else "Nenhum"), inline=True)

                emb.add_field(name="🔑 Key", value=key_masked, inline=True)
                emb.add_field(name="📊 Usos (atual)", value=usos_txt, inline=True)

                emb.add_field(name="👥 Time 1 (Esquerda)", value=team1_txt or "Sem jogadores", inline=True)
                emb.add_field(name="👥 Time 2 (Direita)", value=team2_txt or "Sem jogadores", inline=True)

                emb.add_field(name="Criada em", value=room_info.get("created_at", _utc_now_str()), inline=False)

                if room_info.get("started"):
                    emb.title = "⚡ Partida Iniciada (privado)"
                    emb.color = 0xF97316

                try:
                    await msg_obj.edit(embed=emb)
                except Exception:
                    pass
            except Exception:
                pass

            if auto_end:
                if auto_end <= time.time() and not room_info.get("started"):
                    try:
                        sshash_local = room_info.get("sshash") or str(roomId)
                        resp = await start_room(str(sshash_local), room_info.get("used_key"))
                        if _is_start_success(resp):
                            room_info["started"] = True
                        emb_done = discord.Embed(title="⚡ Partida Iniciada (privado)", color=0xF97316)
                        emb_done.add_field(name="🆔 ID", value=str(roomId), inline=True)
                        emb_done.add_field(name="🔐 Senha", value=str(room_info.get("senha", "—")), inline=True)
                        emb_done.add_field(name="🎮 Modo", value=str(room_info.get("modo_text", "—")), inline=True)
                        emb_done.add_field(name="Nota", value="A sala iniciou (ou já estava iniciada).", inline=False)
                        try:
                            await msg_obj.edit(embed=emb_done, view=None)
                        except Exception:
                            pass
                        return
                    except Exception:
                        room_info.setdefault("last_start_error", "erro ao chamar start_room")

            # espera fixa de 1 segundo por loop (mais responsivo)
            await asyncio.sleep(interval)
    except asyncio.CancelledError:
        return
    except Exception:
        return

# --- Presence: show "X salas criadas 👑" as playing status ---
async def update_presence_loop(interval: int = 30):
    global _presence_task
    if _presence_task and not _presence_task.done():
        return  # already running
    async def _loop():
        try:
            prev = None
            while True:
                try:
                    text = f"{total_rooms_created} salas criadas 👑"
                    if text != prev:
                        try:
                            await bot.change_presence(activity=discord.Game(name=text))
                        except Exception:
                            pass
                        prev = text
                except Exception:
                    pass
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            return
    _presence_task = asyncio.create_task(_loop())

async def _update_presence_once():
    try:
        text = f"{total_rooms_created} salas criadas 👑"
        await bot.change_presence(activity=discord.Game(name=text))
    except Exception:
        pass

async def _ensure_background_tasks():
    """Garante que autosave e presence estejam rodando."""
    global _autosave_task, _presence_task
    if _autosave_task is None or _autosave_task.done():
        _autosave_task = asyncio.create_task(_autosave_state_task())
    if _presence_task is None or _presence_task.done():
        interval_seconds = UPDATE_INTERVAL_SECONDS.get(UPDATE_INTERVAL, 4)
        _presence_task = asyncio.create_task(update_presence_loop(interval=interval_seconds))

@bot.event
async def on_ready():
    """
    Inicialização: cria session partilhada, carrega estado, sincroniza comandos e inicia background tasks.
    Isso é essencial para garantir que os comandos respondam (tree.sync).
    """
    try:
        await get_shared_session()
    except Exception:
        pass

    try:
        # carregue estado persistido (se necessário)
        try:
            load_state()
        except Exception:
            pass

        # sincronizar comandos — globalmente (pode demorar alguns instantes na primeira vez)
        try:
            if GUILD_IDS:
                for gid in GUILD_IDS:
                    try:
                        await tree.sync(guild=discord.Object(id=gid))
                    except Exception:
                        pass
                print("[ready] Commands synced to specified guild(s).")
            else:
                await tree.sync()
                print("[ready] Commands synced (global).")
        except Exception as e:
            print(f"[ready] tree.sync failed: {e}")

        # iniciar tasks de background
        try:
            await _ensure_background_tasks()
        except Exception:
            pass

        # atualização imediata de presença
        try:
            await _update_presence_once()
        except Exception:
            pass

        print(f"[ready] Logged in as {bot.user} — id: {getattr(bot.user, 'id', None)}")
    except Exception as e:
        print(f"[ready] erro durante on_ready: {e}")

# --- Remaining UI commands (config / dev) ---
class ConfigView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=None)
        self.user_id = user_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Apenas o dono pode usar estes botões.", ephemeral=True)
            return False
        return True

    @discord.ui.button(custom_id="senha_btn", label="Senha Fixa", style=discord.ButtonStyle.secondary)
    async def senha_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = SenhaModal(self.user_id)
        await interaction.response.send_modal(modal)

    @discord.ui.button(custom_id="timer_btn", label="Timer", style=discord.ButtonStyle.secondary)
    async def timer_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = TimerModal(self.user_id)
        await interaction.response.send_modal(modal)

    @discord.ui.button(custom_id="key_btn", label="Resgatar Key", style=discord.ButtonStyle.success)
    async def key_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = KeyModal(self.user_id)
        await interaction.response.send_modal(modal)

    @discord.ui.button(custom_id="perfil_btn", label="Perfil", style=discord.ButtonStyle.primary)
    async def perfil_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        user_id = self.user_id
        keys = get_user_keys(user_id)
        total_keys = len(keys)
        per_key_counts: Dict[str, int] = {}
        total_rooms_active = 0
        for rid, info in created_rooms.items():
            if info.get("owner_id") != user_id:
                continue
            km = info.get("key_masked", "—")
            per_key_counts[km] = per_key_counts.get(km, 0) + 1
            total_rooms_active += 1
        global total_rooms_created

        usos_map: Dict[str, str] = {}
        async def _check_key(k):
            info = await verificar_key_info(k)
            usos = _extract_usos(info)
            usos_map[_mask_key(k)] = str(usos) if usos is not None else "—"

        tasks = [asyncio.create_task(_check_key(k)) for k in keys]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        emb = discord.Embed(title="Perfil (privado)", color=0x2F3136)
        emb.add_field(name="Total de keys", value=str(total_keys), inline=True)
        emb.add_field(name="Salas ativas", value=str(total_rooms_active), inline=True)
        emb.add_field(name="Salas criadas (total)", value=str(total_rooms_created), inline=True)
        lines = []
        for k, cnt in per_key_counts.items():
            lines.append(f"{k}: {cnt}")
        emb.add_field(name="Uso por key", value="\n".join(lines) if lines else "Nenhuma", inline=False)
        lines2 = []
        for k, v in usos_map.items():
            lines2.append(f"{k}: {v}")
        emb.add_field(name="Usos restantes (por key)", value="\n".join(lines2) if lines2 else "—", inline=False)
        await interaction.response.send_message(embed=emb, ephemeral=True)

class DevView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=600)
        self.user_id = user_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id not in DEV_IDS:
            await interaction.response.send_message("❌ Você não tem permissão para usar este painel dev.", ephemeral=True)
            return False
        return True

    @discord.ui.button(custom_id="dev_totals", label="Mostrar Totais", style=discord.ButtonStyle.primary)
    async def dev_totals(self, interaction: discord.Interaction, button: discord.ui.Button):
        data = load_json(KEY_FILE)
        total_keys = 0
        for v in data.values():
            if isinstance(v, list):
                total_keys += len(v)
            elif isinstance(v, str):
                total_keys += 1
        total_rooms_active = len(created_rooms)
        global total_rooms_created

        emb = discord.Embed(title="Estatísticas Totais (dev, privado)", color=0x1F8B4C)
        try:
            emb.set_author(name=str(bot.user), icon_url=bot.user.display_avatar.url)
        except Exception:
            pass

        emb.description = f"{total_rooms_created} salas criadas 👑"
        emb.add_field(name="Total de keys (no bot)", value=str(total_keys), inline=True)
        emb.add_field(name="Total de salas ativas (in-memory)", value=str(total_rooms_active), inline=True)
        await interaction.response.send_message(embed=emb, ephemeral=True)

    @discord.ui.button(custom_id="dev_top3", label="Top 3 (digitar dias)", style=discord.ButtonStyle.success)
    async def dev_top3(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = DaysModal(self.user_id)
        await interaction.response.send_modal(modal)

@tree.command(name="criar", description="Criar uma sala automaticamente (privado)")
async def criar_command(interaction: discord.Interaction):
    interval_seconds = UPDATE_INTERVAL_SECONDS.get(UPDATE_INTERVAL, 4)
    embed = discord.Embed(title="Criar Sala (privado)",
                          description=f"Escolha o modo para criar a sala imediatamente.\nAtualizações embed a cada {interval_seconds}s.",
                          color=0x2563EB)
    view = CriarView(interaction.user.id)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

@tree.command(name="config", description="Abrir painel de configurações do FF Salas Bot (privado)")
async def config_command(interaction: discord.Interaction):
    user = interaction.user
    embed = discord.Embed(title="Configurações (privado)", description=f"Bom dia, {user.display_name}", color=0x2F3136)
    try:
        embed.set_thumbnail(url=user.display_avatar.url)
    except Exception:
        pass
    keys_list = get_user_keys(user.id)
    settings = get_user_settings(user.id)
    embed.add_field(name="Status da Key", value=(f"✅ {len(keys_list)} key(s) registrada(s)" if keys_list else "❌ Não registrada"), inline=False)
    embed.add_field(name="Senha Fixa", value=settings.get("senha_fixa", "Nenhuma"), inline=True)
    embed.add_field(name="Auto Start", value=str(settings.get("auto_start", "Nenhum")), inline=True)
    view = ConfigView(user.id)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

# --- Runner with retries/backoff to handle Cloudflare / 429 on login ---
async def _run_with_retries(token: str, max_attempts: int = 12, base_delay: int = 8):
    attempt = 0
    while True:
        attempt += 1
        try:
            print(f"[startup] Iniciando bot (attempt={attempt})...")
            await bot.start(token)
            return
        except discord.errors.HTTPException as e:
            msg = str(e)
            print(f"[startup] discord.HTTPException ao logar (attempt={attempt}): {msg}")
            lowered = msg.lower()
            if "cloudflare" in lowered or "1015" in lowered or "you are being rate limited" in lowered or "too many requests" in lowered or "429" in lowered:
                delay = min(900, base_delay * (2 ** (attempt - 1)))
                delay = int(delay * (0.5 + random.random() * 0.5))
                print(f"[startup] Possível bloqueio Cloudflare/429 detectado. Dormindo {delay}s antes de tentar novamente.")
            else:
                delay = min(300, base_delay * (2 ** (attempt - 1)))
                delay = int(delay * (0.5 + random.random() * 0.5))
                print(f"[startup] HTTPException desconhecida. Dormindo {delay}s antes de tentar novamente.")
            if attempt >= max_attempts:
                print("[startup] Número máximo de tentativas atingido. Abortando startup.")
                traceback.print_exc()
                raise
            await asyncio.sleep(delay)
        except Exception as e:
            print(f"[startup] Exceção ao iniciar (attempt={attempt}): {e}")
            traceback.print_exc()
            if attempt >= max_attempts:
                print("[startup] Número máximo de tentativas atingido para erros gerais. Abortando.")
                raise
            delay = min(300, base_delay * (2 ** (attempt - 1)))
            delay = int(delay * (0.5 + random.random() * 0.5))
            print(f"[startup] Dormindo {delay}s antes de tentar novamente.")
            await asyncio.sleep(delay)
        finally:
            try:
                await close_shared_session()
            except Exception:
                pass

# --- Graceful shutdown helpers ---
async def _shutdown():
    global _autosave_task, _presence_task
    try:
        if _autosave_task:
            _autosave_task.cancel()
            try:
                await _autosave_task
            except Exception:
                pass
    except Exception:
        pass
    try:
        if _presence_task:
            _presence_task.cancel()
            try:
                await _presence_task
            except Exception:
                pass
    except Exception:
        pass
    try:
        save_state()
    except Exception:
        pass
    try:
        await close_shared_session()
    except Exception:
        pass

if __name__ == "__main__":
    try:
        # start runner com retries (vai lidar com 429/cloudflare)
        asyncio.run(_run_with_retries(DISCORD_TOKEN, max_attempts=12, base_delay=8))
    except KeyboardInterrupt:
        print("Recebido KeyboardInterrupt, encerrando...")
        try:
            asyncio.run(_shutdown())
        except Exception:
            pass
    except Exception:
        print("Erro fatal ao iniciar o bot:")
        traceback.print_exc()
        raise